
package romero.yesica.p1.pkg322;

import romero.yesica.p1.pkg322.dominio.AnalisisEstadistico;
import romero.yesica.p1.pkg322.dominio.EstadoActual;
import romero.yesica.p1.pkg322.dominio.Laboratorio;
import romero.yesica.p1.pkg322.dominio.Proyecto;
import romero.yesica.p1.pkg322.dominio.TipoAnalisis;


public class RomeroYesicaP1322 {

    
    public static void main(String[] args) {
       Laboratorio lab = new Laboratorio("Baus");
        Proyecto p1 = new AnalisisEstadistico("Comportamiento de Usuarios", " DataLab-B", EstadoActual.FINALIZADO, TipoAnalisis.PREDICTIVO);
       //  Proyecto p2 = new AnalisisEstadistico("Comportamiento de Usuarios", " DataLab-B", EstadoActual.FINALIZADO, TipoAnalisis.PREDICTIVO);
        agregarProyectoAlLaboratorio(lab, p1);
        //agregarProyectoAlLaboratorio(lab, p2);
        mostrarProyectosDelLaboratorio(lab);
        
       
    }
    
    public static  void agregarProyectoAlLaboratorio(Laboratorio laboratorio, Proyecto nuevo){
        laboratorio.agregarProyecto(nuevo);
        System.out.println("Proyecto agregado correctamente");
      }
    
     public static  void mostrarProyectosDelLaboratorio(Laboratorio laboratorio){
         System.out.println(laboratorio.mostrarProyectos());
      }
    
}
