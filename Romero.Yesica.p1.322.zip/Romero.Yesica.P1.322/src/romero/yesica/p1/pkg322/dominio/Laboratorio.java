
package romero.yesica.p1.pkg322.dominio;

import java.util.ArrayList;
import java.util.List;


public class Laboratorio {
    private String nombre;
    private List<Proyecto> proyectos;

    public Laboratorio(String nombre) {
        this.nombre = nombre;
        this.proyectos = new ArrayList<>();
    }
    
    public void agregarProyecto(Proyecto nuevoProyecto){
        validarProyecto(nuevoProyecto);
        proyectos.add(nuevoProyecto);
    }
   
     private void validarProyecto(Proyecto nuevoProyecto) {
        if(nuevoProyecto == null || proyectos.contains(nuevoProyecto)){
            throw new IllegalArgumentException("Proyecto Repetido o nulo");
        }
    }
     
     public String mostrarProyectos(){
         StringBuilder sb = new StringBuilder();
         
         for(Proyecto p : proyectos){
             sb.append(p);
         }
         return sb.toString();
     }
     
     public void actualizarResultadosProyectos(){
          for(Proyecto p : proyectos){
              p.actualizarResultados();
             
}
     }
     
     public void actualizarEstadoProyectos(EstadoActual estado){
        if (validarEstado(estado) && hayProyectosRegistrados() && seModificoAlgunEstado(estado)) {
            for (Proyecto p : proyectos) {
                p.setEstado(estado);
            }
        }else {
                System.out.println("No se realizo ninguna modifiocacion");
                }

    }

    private boolean validarEstado(EstadoActual estado) {
        return estado != null;
    }
    
    private boolean hayProyectosRegistrados(){
        return !proyectos.isEmpty();
    }
    
    private boolean seModificoAlgunEstado(EstadoActual estado){
         for(Proyecto p : proyectos){
           if(p.getEstadoProyecto() != estado){
               return true;
           }
        }
         return false;
    }
    
     }
    


