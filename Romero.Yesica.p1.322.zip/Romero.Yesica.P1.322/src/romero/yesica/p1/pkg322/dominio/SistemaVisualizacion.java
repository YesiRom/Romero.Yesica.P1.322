/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package romero.yesica.p1.pkg322.dominio;

/**
 *
 * @author Usuario
 */
public class SistemaVisualizacion extends Proyecto{
    private int cantidadDeGraficos;

    public SistemaVisualizacion(String nombre, String equipoRespontable, EstadoActual estado, int cantGraficos) {
        super(nombre, equipoRespontable, estado);
        this.cantidadDeGraficos = cantGraficos;
    }

    @Override
    public String toString() {
        return  super.toString() + "\nCantidad De Graficos = " + cantidadDeGraficos + "\n_____________________________";
    }
    
     @Override
    public void actualizarResultados() {
        System.out.println("Sistema de visualizacion no puede ser actualizado");
    }
   
}
