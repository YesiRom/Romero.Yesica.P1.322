/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package romero.yesica.p1.pkg322.dominio;

/**
 *
 * @author Usuario
 */
public class AnalisisEstadistico extends Proyecto{
    private TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoRespontable,EstadoActual estado, TipoAnalisis tipo) {
        super(nombre, equipoRespontable, estado);
        this.tipoAnalisis = tipo;
    }

    @Override
    public String toString() {
        return super.toString() + "\nTipo de Analisis = " + tipoAnalisis +"\n_____________________________";
    }
    
    @Override
    public void actualizarResultados() {
        System.out.println("Resultado Actualizado");
    }
    
    
}
