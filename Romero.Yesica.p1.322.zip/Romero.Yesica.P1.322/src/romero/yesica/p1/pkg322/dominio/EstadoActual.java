/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package romero.yesica.p1.pkg322.dominio;

/**
 *
 * @author Usuario
 */
public enum EstadoActual {
    EN_DESARROLLO,
ENTRENANDO_MODELO,
FINALIZADO;
}
