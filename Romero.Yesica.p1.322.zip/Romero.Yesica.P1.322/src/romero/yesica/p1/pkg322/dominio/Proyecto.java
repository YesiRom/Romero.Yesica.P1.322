/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package romero.yesica.p1.pkg322.dominio;

import java.util.Objects;

/**
 *
 * @author Usuario
 */
public abstract class Proyecto {
    private String nombre;
    private String equipoRespontable;
    private EstadoActual estadoProyecto;

    public Proyecto(String nombre, String equipoRespontable, EstadoActual estado) {
        this.nombre = nombre;
        this.equipoRespontable = equipoRespontable;
        this.estadoProyecto = estado;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, equipoRespontable);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Proyecto p)) {
            return false;
        }
        return nombre.equals(p.nombre) && equipoRespontable.equals(p.equipoRespontable);
    }

    @Override
    public String toString() {
        return "Nombre del Proyecto = " + nombre + "\n Equipo Respontable = " + equipoRespontable;
    }

   public void setEstado(EstadoActual estado) {
       this.estadoProyecto = estado;
    }

   public abstract void actualizarResultados();

    public EstadoActual getEstadoProyecto() {
        return estadoProyecto;
    }
   
   
       
    
   
    
   
    
}
