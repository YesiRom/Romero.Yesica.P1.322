
package romero.yesica.p1.pkg322.dominio;


public class EsDuplicadoException extends RuntimeException {
  private static final String MENSAJE = "Proyecto Duplicado";
  
    public EsDuplicadoException() {
        this(MENSAJE);
                
    }
    
    public EsDuplicadoException(String mensaje){
        super(mensaje);
    }
    
}
