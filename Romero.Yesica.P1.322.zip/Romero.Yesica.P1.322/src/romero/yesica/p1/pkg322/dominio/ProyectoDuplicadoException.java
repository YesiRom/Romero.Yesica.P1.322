
package romero.yesica.p1.pkg322.dominio;


public class ProyectoDuplicadoException extends RuntimeException{
    private static final String MENSAJE = "Proyecto Duplicado";

    public ProyectoDuplicadoException() {
        this(MENSAJE);
    }

    public ProyectoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
