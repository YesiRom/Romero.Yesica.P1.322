
package romero.yesica.p1.pkg322.dominio;


public class ModeloMachineLearning extends Proyecto implements IActualizable{
    private static final double MIN_PORC = 0;
    private static final double MAX_PORC = 0;
    private double porcDePrecision;

    public ModeloMachineLearning(String nombre, String equipoRespontable,EstadoActual estado, double porcentaje) {
        super(nombre, equipoRespontable, estado);
        this.porcDePrecision = porcentaje;
    }

    @Override
    public String toString() {
        return super.toString() + "\n Porcentaje de precision = " + porcDePrecision + "\n_____________________________";
    }

    @Override
    public String actualizarResultados() {
      return "Modelo Machine Learning  " +  getNombre() + " se esta actualizando...";
    }

    
    
    
}

