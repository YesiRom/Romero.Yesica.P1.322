
package romero.yesica.p1.pkg322.dominio;


public class SistemaVisualizacion extends Proyecto{
    private int cantidadDeGraficos;

    public SistemaVisualizacion(String nombre, String equipoRespontable, EstadoActual estado, int cantGraficos) {
        super(nombre, equipoRespontable, estado);
        this.cantidadDeGraficos = cantGraficos;
    }

    @Override
    public String toString() {
        return  super.toString() + "\nCantidad De Graficos = " + cantidadDeGraficos + "\n_____________________________";
    }
    
    
   
}
