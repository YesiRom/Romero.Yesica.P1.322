
package romero.yesica.p1.pkg322.dominio;


public class AnalisisEstadistico extends Proyecto implements IActualizable{
    private TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoRespontable,EstadoActual estado, TipoAnalisis tipo) {
        super(nombre, equipoRespontable, estado);
        this.tipoAnalisis = tipo;
    }

    @Override
    public String toString() {
        return super.toString() + "\nTipo de Analisis = " + tipoAnalisis +"\n_____________________________";
    }

   
      @Override
    public String actualizarResultados() {
      return "Analisis Estadisticos " +  getNombre() + " se esta actualizando...";
    }


      
    
}
