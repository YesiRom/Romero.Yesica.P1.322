
package romero.yesica.p1.pkg322.dominio;


public interface IActualizable {
    String actualizarResultados();
}
