
package romero.yesica.p1.pkg322.dominio;

import java.util.Objects;


public abstract class Proyecto {
    private String nombre;
    private String equipoRespontable;
    private EstadoActual estadoProyecto;

    public Proyecto(String nombre, String equipoRespontable, EstadoActual estado) {
        this.nombre = nombre;
        this.equipoRespontable = equipoRespontable;
        this.estadoProyecto = estado;
    }
    
     public void setEstado(EstadoActual estadoNuevo) {
         validarEstado(estadoNuevo);
        this.estadoProyecto = estadoNuevo;
    }
     
      private void validarEstado(EstadoActual estadoNuevo) {
        if(estadoNuevo == null){
            throw new IllegalArgumentException("Estado nulo");
        }
    }

    public EstadoActual getEstadoProyecto() {
        return estadoProyecto;
    }
    
    public String getNombre(){
        return this.nombre;
    }
   
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre, equipoRespontable);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Proyecto p)) {
            return false;
        }
        return nombre.equals(p.nombre) && equipoRespontable.equals(p.equipoRespontable);
    }

    @Override
    public String toString() {
        return "Nombre del Proyecto = " + nombre + "\nEquipo Respontable = " + equipoRespontable + "\nEstado = " + estadoProyecto;
    }

   

    
    
}
