
package romero.yesica.p1.pkg322.dominio;

import java.util.ArrayList;
import java.util.List;


public class Laboratorio {
    private List<Proyecto> proyectos;

    public Laboratorio() {
         this.proyectos = new ArrayList<>();
    }
    
    public void agregarProyecto(Proyecto nuevoProyecto){
        validarProyectoNoNull(nuevoProyecto);
        validarProyectoDuplicado(nuevoProyecto);
        proyectos.add(nuevoProyecto);
    }
   
     private void validarProyectoNoNull(Proyecto nuevoProyecto) {
        if(nuevoProyecto == null){
            throw new IllegalArgumentException("El proyecto es nulo");
        }
    }
     
     private void validarProyectoDuplicado(Proyecto proyecto) {
        if (proyectos.contains(proyecto)) {
            throw new ProyectoDuplicadoException("No se puede agregar un proyecto repetido!!");
        }
       
    }
     
     public String mostrarProyectos(){
         StringBuilder sb = new StringBuilder("********  PROYECTOS *********** \n");
         
         for(Proyecto p : proyectos){
             sb.append(p).append("\n");
         }
         return sb.toString();
     }
     
     public String  actualizarResultadosProyectos(){
         StringBuilder sb = new StringBuilder();
         
          for(Proyecto pro : proyectos){
              if(pro instanceof IActualizable p){
                  sb.append(p.actualizarResultados());
              }else {
                  sb.append("Los sistemas de Visualizacion:  ").append(pro.getNombre()).append(", no pueden actualizarse directamente..");
              }
             sb.append("\n");
            }
          return sb.toString();
     }
     
     
     
     
     public String actualizarEstadoProyectos(EstadoActual estado){
         int contador = 0;
        if (validarEstado(estado) && hayProyectosRegistrados() && hayEstadosAModificar(estado)) {
            for (Proyecto p : proyectos) {
                if(p.getEstadoProyecto() != estado){
                      p.setEstado(estado);
                contador++;
                }
              
            }
        }else {
                return "No se realizo ninguna modificacion";
                }
       return mostrarProyectos() + "\nCantidad de Proyectos actualizados : " + contador;
    }

    private boolean validarEstado(EstadoActual estado) {
        return estado != null;
    }
    
    private boolean hayProyectosRegistrados(){
        return !proyectos.isEmpty();
    }
    
    private boolean hayEstadosAModificar(EstadoActual estado){
         for(Proyecto p : proyectos){
           if(p.getEstadoProyecto() != estado){
               return true;
           }
        }
         return false;
    }

    
    
     }
    


