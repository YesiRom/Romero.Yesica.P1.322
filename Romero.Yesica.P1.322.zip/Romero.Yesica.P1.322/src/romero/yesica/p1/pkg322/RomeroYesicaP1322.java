
package romero.yesica.p1.pkg322;

import romero.yesica.p1.pkg322.dominio.AnalisisEstadistico;
import romero.yesica.p1.pkg322.dominio.EstadoActual;
import romero.yesica.p1.pkg322.dominio.Laboratorio;
import romero.yesica.p1.pkg322.dominio.ModeloMachineLearning;
import romero.yesica.p1.pkg322.dominio.Proyecto;
import romero.yesica.p1.pkg322.dominio.ProyectoDuplicadoException;
import romero.yesica.p1.pkg322.dominio.SistemaVisualizacion;
import romero.yesica.p1.pkg322.dominio.TipoAnalisis;


public class RomeroYesicaP1322 {

    
    public static void main(String[] args) {
      
        Laboratorio lab = inicializarLaboratorio();
        
        // Intenta agregar un proyecto duplicado y lanza una excepcion
        
          try {
           lab.agregarProyecto(new AnalisisEstadistico("Sales Marinas", " DataScien", EstadoActual.ENTRENANDO_MODELO, TipoAnalisis.DESCRIPTIVO));
        } catch (ProyectoDuplicadoException exception) {
            System.out.println(exception.getMessage());
        }
        
            
       // Muestra por pantalla todos los proyectos del laboratorio
       
        mostrarProyectosDelLaboratorio(lab);
       
        // Actualiza los resultados de los proyectos que implementan IActualizable
         actualizarResultadosProyectos(lab);
        
        
        //ACTUALIZAR EL ESTADO DE UN PROYECTO POR UNO NUEVO
       actualizarEstadoProyectos(lab, EstadoActual.FINALIZADO);
        
       
      
       
    }
    
    public static Laboratorio inicializarLaboratorio(){
         Laboratorio lab = new Laboratorio();
         Proyecto [] proyectos = {new AnalisisEstadistico("Comportamiento de Usuarios", " DataLab-B", EstadoActual.FINALIZADO, TipoAnalisis.PREDICTIVO),
        new AnalisisEstadistico("Sales Marinas", " DataScien", EstadoActual.ENTRENANDO_MODELO, TipoAnalisis.DESCRIPTIVO),
        new AnalisisEstadistico("Elecciones 2025", " Encuest", EstadoActual.EN_DESARROLLO, TipoAnalisis.INFERENCIAL),
        new AnalisisEstadistico("Comportamiento de fauna", " National", EstadoActual.FINALIZADO, TipoAnalisis.INFERENCIAL),
        new ModeloMachineLearning("Uala", "moreno", EstadoActual.FINALIZADO, 96),
        new ModeloMachineLearning("Face", "Amazon", EstadoActual.ENTRENANDO_MODELO, 50),
        new SistemaVisualizacion("Abv", "Conicec", EstadoActual.EN_DESARROLLO, 5),
        new SistemaVisualizacion("Bgh", "Conicec", EstadoActual.ENTRENANDO_MODELO, 7)};
         
         
        for (Proyecto p : proyectos) {
            agregarProyectoAlLaboratorio(lab, p);
        }
        return lab;
        
        }
    
    
    private static  void agregarProyectoAlLaboratorio(Laboratorio laboratorio, Proyecto nuevo){
        laboratorio.agregarProyecto(nuevo);
      }
    
     private static  void mostrarProyectosDelLaboratorio(Laboratorio laboratorio){
         System.out.println(laboratorio.mostrarProyectos());
      }
    
     public static void  actualizarResultadosProyectos(Laboratorio laboratorio){
         System.out.println(laboratorio.actualizarResultadosProyectos());
        
         
     }
     
     public static void  actualizarEstadoProyectos(Laboratorio lab, EstadoActual nuevoEstado){
         System.out.println(lab.actualizarEstadoProyectos(nuevoEstado)); 
     }
}
